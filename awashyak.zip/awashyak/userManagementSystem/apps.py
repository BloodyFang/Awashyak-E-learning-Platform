from django.apps import AppConfig


class UsermanagementsystemConfig(AppConfig):
    name = 'userManagementSystem'
